/**
 * MozartSpaces - Java implementation of Extensible Virtual Shared Memory (XVSM)
 * Copyright 2009-2012 Space Based Computing Group, eva Kuehn, E185/1, TU Vienna
 * Visit http://www.mozartspaces.org for more information.
 *
 * MozartSpaces is free software: you can redistribute it and/or
 * modify it under the terms of version 3 of the GNU Affero General
 * Public License as published by the Free Software Foundation.
 *
 * MozartSpaces is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General
 * Public License along with MozartSpaces. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.mozartspaces.core;

import java.net.URI;

import net.jcip.annotations.Immutable;

/**
 * Identifies a transaction in the XVSM universe. A
 * <code>TransactionReference</code> is used in the Core to specify a
 * transaction, because outside of the Runtime no direct reference to the actual
 * transaction object is accessible for security reasons.
 *
 * @author Tobias Doenz
 */
@Immutable
public final class TransactionReference extends Reference<String> {

    private static final long serialVersionUID = 1L;

    /**
     * The prefix for the path part of the URI representation, used by
     * {@link #toString()}.
     */
    public static final String PATH_PREFIX = "/transactions/transaction/";

    /**
     * Constructs a <code>TransactionReference</code>.
     *
     * @param id
     *            the transaction id, unique within a space (or core)
     * @param space
     *            the URI to identify the space
     */
    public TransactionReference(final String id, final URI space) {
        super(id, space);
    }

    @Override
    public String toString() {
        return getSpace() + PATH_PREFIX + getId();
    }

}
