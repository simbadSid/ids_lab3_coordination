/**
 * MozartSpaces - Java implementation of Extensible Virtual Shared Memory (XVSM)
 * Copyright 2009-2012 Space Based Computing Group, eva Kuehn, E185/1, TU Vienna
 * Visit http://www.mozartspaces.org for more information.
 *
 * MozartSpaces is free software: you can redistribute it and/or
 * modify it under the terms of version 3 of the GNU Affero General
 * Public License as published by the Free Software Foundation.
 *
 * MozartSpaces is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General
 * Public License along with MozartSpaces. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.mozartspaces.capi3.javanative.isolation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import net.jcip.annotations.ThreadSafe;

import org.mozartspaces.capi3.InvalidTransactionException;
import org.mozartspaces.capi3.LocalContainerReference;
import org.mozartspaces.capi3.LogItem;
import org.mozartspaces.capi3.SubTransaction;
import org.mozartspaces.capi3.TransactionStatus;

/**
 * The <code>NativeTransaction</code> is responsible to provide transactional
 * safety in the application.
 *
 * @author Martin Barisits
 * @author Tobias Doenz
 */
@ThreadSafe
public final class DefaultTransaction implements NativeTransaction {

    private static final AtomicLong ID_COUNTER = new AtomicLong();

    private final String id;
    private final List<NativeSubTransaction> subTransactions;
    private final List<LogItem> otherLog;
    private final AtomicBoolean active;
    private final AtomicLong stxCounter;

    private volatile TransactionStatus status;
    private volatile boolean locked;

    /**
     * The number of currently not finished sub transactions.
     */
    private final AtomicInteger notFinishedSubTransactionCounter;
    private CountDownLatch allSubTransactionsFinished;

    /**
     * Constructor for the DefaultTransaction.
     */
    public DefaultTransaction() {
        this.id = Long.toString(ID_COUNTER.incrementAndGet());
        this.subTransactions = Collections.synchronizedList(new ArrayList<NativeSubTransaction>());
        this.otherLog = new ArrayList<LogItem>();
        this.active = new AtomicBoolean(true);
        this.stxCounter = new AtomicLong();

        this.status = TransactionStatus.RUNNING;

        this.notFinishedSubTransactionCounter = new AtomicInteger();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void commit() throws InvalidTransactionException {

        if (!this.active.getAndSet(false)) {
            throw new InvalidTransactionException(this.getId());
        }

        List<NativeSubTransaction> stxToCommit = checkSubTransactionStatus();
        this.status = TransactionStatus.COMMITING;

        /* Commit Delete Log */
        for (NativeSubTransaction stx : stxToCommit) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getDeleteLog()) {
                l.commitTransaction();
            }
        }

        /* Commit Insert Log */
        for (NativeSubTransaction stx : stxToCommit) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getInsertLog()) {
                l.commitTransaction();
            }
        }

        /* Commit Read Log */
        for (NativeSubTransaction stx : stxToCommit) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getReadLog()) {
                l.commitTransaction();
            }
        }

        /* Commit Lock Log */
        for (NativeSubTransaction stx : stxToCommit) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getLockLog()) {
                l.commitTransaction();
            }
        }

        /* Commit Sub-Transations' Other Log */
        for (NativeSubTransaction stx : stxToCommit) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getOtherLog()) {
                l.commitTransaction();
            }
        }

        /* Commit Transaction's Other Log */
        for (LogItem l : this.otherLog) {
            l.commitTransaction();
        }

        this.status = TransactionStatus.COMMITED;

    }

    private List<NativeSubTransaction> checkSubTransactionStatus() {
        List<NativeSubTransaction> committedStx = new ArrayList<NativeSubTransaction>();
        for (NativeSubTransaction stx : this.subTransactions) {
            if (stx.getStatus().equals(TransactionStatus.RUNNING)
                    || stx.getStatus().equals(TransactionStatus.COMMITING)
                    || stx.getStatus().equals(TransactionStatus.ABORTING)) {
                throw new RuntimeException("SubTransaction " + stx.getId() + " is still running");
                // TODO throw more specific exception
            }
            if (stx.getStatus().equals(TransactionStatus.COMMITED)) {
                committedStx.add(stx);
            }
        }
        return committedStx;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void rollback() throws InvalidTransactionException {

        if (!this.active.getAndSet(false)) {
            throw new InvalidTransactionException(this.getId());
        }

        List<NativeSubTransaction> stxToRollback = checkSubTransactionStatus();
        this.status = TransactionStatus.ABORTING;

        /* Rollback Delete Log */
        for (NativeSubTransaction stx : stxToRollback) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getDeleteLog()) {
                l.rollbackTransaction();
            }
        }

        /* Rollback Read Log */
        for (NativeSubTransaction stx : stxToRollback) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getReadLog()) {
                l.rollbackTransaction();
            }
        }

        /* Rollback Insert Log */
        for (NativeSubTransaction stx : stxToRollback) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getInsertLog()) {
                l.rollbackTransaction();
            }
        }

        /* Rollback Lock Log */
        for (NativeSubTransaction stx : stxToRollback) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getLockLog()) {
                l.rollbackTransaction();
            }
        }

        /* Rollback Sub-Transactions' Other Log */
        for (NativeSubTransaction stx : stxToRollback) {
            DefaultSubTransaction dStx = (DefaultSubTransaction) stx;
            for (LogItem l : dStx.getOtherLog()) {
                l.rollbackTransaction();
            }
        }

        /* Rollback Transaction's Other Log */
        for (LogItem l : this.otherLog) {
            l.rollbackTransaction();
        }

        this.status = TransactionStatus.ABORTED;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return this.id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SubTransaction newSubTransaction() throws InvalidTransactionException {
        if (this.active.get() && !locked) {
            NativeSubTransaction stx = new DefaultSubTransaction(this, this.stxCounter.getAndIncrement());
            this.subTransactions.add(stx);
            notFinishedSubTransactionCounter.incrementAndGet();
            return stx;
        }
        throw new InvalidTransactionException(this.getId());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object obj) {
        return (obj instanceof NativeTransaction) && (this.id.equals(((NativeTransaction) obj).getId()));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + id.hashCode();
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized List<LogItem> getLog() {
        ArrayList<LogItem> log = new ArrayList<LogItem>();
        for (NativeSubTransaction stx : this.subTransactions) {
            log.addAll(((DefaultSubTransaction) stx).getInsertLog());
            log.addAll(((DefaultSubTransaction) stx).getReadLog());
            log.addAll(((DefaultSubTransaction) stx).getDeleteLog());
            log.addAll(((DefaultSubTransaction) stx).getLockLog());
            log.addAll(((DefaultSubTransaction) stx).getOtherLog());
        }
        log.addAll(this.otherLog);
        return log;
    }

    // TODO use set or list?
    @Override
    public synchronized Collection<LocalContainerReference> getAccessedContainers() {
        Collection<LocalContainerReference> containers = new HashSet<LocalContainerReference>();
        for (NativeSubTransaction stx : this.subTransactions) {
            containers.addAll(((DefaultSubTransaction) stx).getAccessedContainers());
        }
        return containers;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public TransactionStatus getStatus() {
        return this.status;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public synchronized void addLog(final LogItem logItem) throws InvalidTransactionException {
        if (logItem == null) {
            throw new NullPointerException("The logItem must not be null");
        }
        this.otherLog.add(logItem);
    }

    @Override
    public boolean isValid() {
        return getStatus() != TransactionStatus.COMMITED && getStatus() != TransactionStatus.ABORTED;
    }

    @Override
    public void lockAndWaitForSubTransactions() throws InterruptedException {
        this.locked = true;
        synchronized (this.notFinishedSubTransactionCounter) {
            if (this.notFinishedSubTransactionCounter.get() > 0) {
                allSubTransactionsFinished = new CountDownLatch(1);
            }
        }
        if (allSubTransactionsFinished != null) {
            allSubTransactionsFinished.await();
        }
    }

    @Override
    public boolean isLocked() {
        return this.locked;
    }

    @Override
    public void subTransactionFinished() {
        if (this.notFinishedSubTransactionCounter.decrementAndGet() == 0) {
            synchronized (this.notFinishedSubTransactionCounter) {
                if (allSubTransactionsFinished != null) {
                    allSubTransactionsFinished.countDown();
                }
            }
        }
    }

}
