/**
 * MozartSpaces - Java implementation of Extensible Virtual Shared Memory (XVSM)
 * Copyright 2009-2012 Space Based Computing Group, eva Kuehn, E185/1, TU Vienna
 * Visit http://www.mozartspaces.org for more information.
 *
 * MozartSpaces is free software: you can redistribute it and/or
 * modify it under the terms of version 3 of the GNU Affero General
 * Public License as published by the Free Software Foundation.
 *
 * MozartSpaces is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General
 * Public License along with MozartSpaces. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.mozartspaces.capi3.javanative.coordination.query.index.result;

import java.util.Collections;
import java.util.Set;

import org.mozartspaces.capi3.Property.EqualMatchmaker;
import org.mozartspaces.capi3.QueryIndex.IndexType;
import org.mozartspaces.capi3.javanative.coordination.query.index.SearchIndex;
import org.mozartspaces.capi3.javanative.coordination.query.index.SearchIndexManager;
import org.mozartspaces.capi3.javanative.operation.NativeEntry;

/**
 * @author Martin Planer
 */
public final class IndexEqualResult implements IndexResult {

    private final Set<NativeEntry> entries;
    private final Set<Class<?>> indexedClasses;

    private IndexEqualResult(final Set<NativeEntry> entries, final Set<Class<?>> set) {
        this.indexedClasses = Collections.unmodifiableSet(set);
        this.entries = Collections.unmodifiableSet(entries);
    }

    @Override
    public Set<NativeEntry> getEntries() {
        return entries;
    }

    @Override
    public Set<Class<?>> getIndexedClasses() {
        return indexedClasses;
    }

    public static IndexResult newQueryIndexResult(final EqualMatchmaker matchmaker,
            final SearchIndexManager indexManager) {

        // Don't allow value property comparisons
        if (matchmaker.getValue() == null) {
            return null;
        }

        SearchIndex index = indexManager.getIndex(matchmaker.getProperty().getPath(), IndexType.BASIC);

        if (index == null) {
            return null;
        }

        Set<NativeEntry> entries = index.lookupEqualTo(matchmaker.getValue(), matchmaker.getProperty().getEntryClazz());

        return new IndexEqualResult(entries, index.getIndexedClasses());
    }
}
