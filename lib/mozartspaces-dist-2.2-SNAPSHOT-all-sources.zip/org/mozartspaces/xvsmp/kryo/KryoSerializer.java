/**
 * MozartSpaces - Java implementation of Extensible Virtual Shared Memory (XVSM)
 * Copyright 2009-2012 Space Based Computing Group, eva Kuehn, E185/1, TU Vienna
 * Visit http://www.mozartspaces.org for more information.
 *
 * MozartSpaces is free software: you can redistribute it and/or
 * modify it under the terms of version 3 of the GNU Affero General
 * Public License as published by the Free Software Foundation.
 *
 * MozartSpaces is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General
 * Public License along with MozartSpaces. If not, see
 * <http://www.gnu.org/licenses/>.
 */
package org.mozartspaces.xvsmp.kryo;

import java.net.URI;
import java.nio.ByteBuffer;

import net.jcip.annotations.ThreadSafe;

import org.mozartspaces.core.ContainerReference;
import org.mozartspaces.core.RequestReference;
import org.mozartspaces.core.TransactionReference;
import org.mozartspaces.core.aspects.AspectReference;
import org.mozartspaces.core.util.SerializationException;
import org.mozartspaces.core.util.Serializer;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.ObjectBuffer;
import com.esotericsoftware.kryo.serialize.IntSerializer;
import com.esotericsoftware.kryo.serialize.ReferenceFieldSerializer;
import com.esotericsoftware.kryo.serialize.StringSerializer;

/**
 * Binary serializer that uses the kryo serialization library.
 *
 * @author Tobias Doenz
 */
@ThreadSafe
public final class KryoSerializer implements Serializer {

    private final Kryo kryo;
    private final ThreadLocal<ObjectBuffer> objectBuffer;

    /**
     * Constructs a <code>KryoSerializer</code>.
     */
    public KryoSerializer() {
        kryo = new Kryo() {
            @Override
            protected com.esotericsoftware.kryo.Serializer newDefaultSerializer(
                    @SuppressWarnings("rawtypes") final Class type) {
                if (type.getClass().isInstance(Exception.class)) {
                    return new ReferenceFieldSerializer(this, type);
                }
                return super.newDefaultSerializer(type);
            }
        };
        kryo.setRegistrationOptional(true);
        objectBuffer = new ThreadLocal<ObjectBuffer>() {
            @Override
            protected ObjectBuffer initialValue() {
                return new ObjectBuffer(kryo, 1024, 1024 * 1024);
            }
        };
        // TODO register all (known) API classes?
        // kryo.register(Entry.class);

        kryo.register(StackTraceElement.class, new StackTraceElementSerializer(kryo));

        // serializer for reference classes, necessary because of transient spaceURI field
        kryo.register(RequestReference.class,
                new com.esotericsoftware.kryo.serialize.SimpleSerializer<RequestReference>() {
                    @Override
                    public RequestReference read(final ByteBuffer buffer) {
                        String id = StringSerializer.get(buffer);
                        String space = StringSerializer.get(buffer);
                        return new RequestReference(id, URI.create(space));
                    }

                    @Override
                    public void write(final ByteBuffer buffer, final RequestReference ref) {
                        StringSerializer.put(buffer, ref.getId());
                        StringSerializer.put(buffer, ref.getSpace().toString());
                    }
                });
        kryo.register(ContainerReference.class,
                new com.esotericsoftware.kryo.serialize.SimpleSerializer<ContainerReference>() {
                    @Override
                    public ContainerReference read(final ByteBuffer buffer) {
                        String id = StringSerializer.get(buffer);
                        String space = StringSerializer.get(buffer);
                        return new ContainerReference(id, URI.create(space));
                    }

                    @Override
                    public void write(final ByteBuffer buffer, final ContainerReference ref) {
                        StringSerializer.put(buffer, ref.getId());
                        StringSerializer.put(buffer, ref.getSpace().toString());
                    }
                });
        kryo.register(TransactionReference.class,
                new com.esotericsoftware.kryo.serialize.SimpleSerializer<TransactionReference>() {
                    @Override
                    public TransactionReference read(final ByteBuffer buffer) {
                        String id = StringSerializer.get(buffer);
                        String space = StringSerializer.get(buffer);
                        return new TransactionReference(id, URI.create(space));
                    }

                    @Override
                    public void write(final ByteBuffer buffer, final TransactionReference ref) {
                        StringSerializer.put(buffer, ref.getId());
                        StringSerializer.put(buffer, ref.getSpace().toString());
                    }
                });
        kryo.register(AspectReference.class,
                new com.esotericsoftware.kryo.serialize.SimpleSerializer<AspectReference>() {
                    @Override
                    public AspectReference read(final ByteBuffer buffer) {
                        String id = StringSerializer.get(buffer);
                        String space = StringSerializer.get(buffer);
                        return new AspectReference(id, URI.create(space));
                    }

                    @Override
                    public void write(final ByteBuffer buffer, final AspectReference ref) {
                        StringSerializer.put(buffer, ref.getId());
                        StringSerializer.put(buffer, ref.getSpace().toString());
                    }
                });
    }

    /**
     * @return the Kryo instance
     */
    public Kryo getKryo() {
        return kryo;
    }

    @Override
    public <T> byte[] serialize(final T object) throws SerializationException {
        return objectBuffer.get().writeClassAndObject(object);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T deserialize(final byte[] serializedObject) throws SerializationException {
        return (T) objectBuffer.get().readClassAndObject(serializedObject);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T copyObject(final T object) throws SerializationException {
        return (T) deserialize(serialize(object));
    }

    /**
     * Serializer for {@code StackTraceElement}.
     */
    private static class StackTraceElementSerializer extends
            com.esotericsoftware.kryo.serialize.SimpleSerializer<StackTraceElement> {

        private final Kryo kryo;

        StackTraceElementSerializer(final Kryo kryo) {
            this.kryo = kryo;
        }

        @Override
        public StackTraceElement read(final ByteBuffer buffer) {
            String declaringClass = StringSerializer.get(buffer);
            String methodName = StringSerializer.get(buffer);
            String fileName = kryo.readObject(buffer, String.class);
            int lineNumber = IntSerializer.get(buffer, true);
            return new StackTraceElement(declaringClass, methodName, fileName, lineNumber);
        }

        @Override
        public void write(final ByteBuffer buffer, final StackTraceElement ste) {
            StringSerializer.put(buffer, ste.getClassName());
            StringSerializer.put(buffer, ste.getMethodName());
            kryo.writeObject(buffer, ste.getFileName());
            IntSerializer.put(buffer, ste.getLineNumber(), true);
        }
    }

}
